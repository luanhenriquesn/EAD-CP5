﻿using Fiap.Web.CheckPoint02.Models;
using Fiap.Web.CheckPoint02.Persistencia;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fiap.Web.CheckPoint02.Controllers
{
    public class CarroController : Controller
    {

        private CorridaContext _context;


        public CarroController(CorridaContext context)
        {
            _context = context;
        }


        private void CarregarEquipes()
        {
            List<Equipe> equipes = _context.Equipes.OrderBy(eq => eq.Nome).ToList();
            ViewBag.equipes = new SelectList(equipes, "EquipeId", "Nome");
        }


        //---------------------------------------------------------------------

        public IActionResult Index(string nomeMarca, string nomeModelo)
        {
            List<Carro> carros = _context.Carros.Where(car =>
                (car.Marca.Contains(nomeMarca) || nomeMarca == null) &&
                (car.Modelo.Contains(nomeModelo) || nomeModelo == null))
                .Include(car => car.Piloto).Include(car => car.Equipe).ToList();
            return View(carros);
        }


        //-----------------------------------------

        [HttpGet]
        public IActionResult Cadastrar()
        {
            CarregarEquipes();
            return View();
        }


        [HttpPost]
        public IActionResult Cadastrar(Carro carro)
        {
            _context.Carros.Add(carro);
            _context.SaveChanges();
            TempData["msg"] = "Carro Cadastrado com SUCESSO !!!";
            return RedirectToAction("Index");
        }

        //----------------------------------------

        [HttpGet]
        public IActionResult Editar(int id)
        {
            CarregarEquipes();
            Carro carro = _context.Carros.Find(id);
            return View(carro);
        }

        [HttpPost]
        public IActionResult Editar(Carro carro)
        {
            _context.Carros.Update(carro);
            _context.SaveChanges();
            TempData["msg"] = "Carro Editado com SUCESSO !!!";
            return RedirectToAction("Index");
        }

        //-------------------------------------

        [HttpPost]
        public IActionResult Remover(int id)
        {
            Carro carro = _context.Carros.Find(id);
            _context.Carros.Remove(carro);
            _context.SaveChanges();
            TempData["msg"] = "Carro Removido com SUCESSO !!!";
            return RedirectToAction("Index");
        }


    }
}
