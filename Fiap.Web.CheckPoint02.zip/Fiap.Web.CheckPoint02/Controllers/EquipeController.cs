﻿using Fiap.Web.CheckPoint02.Models;
using Fiap.Web.CheckPoint02.Persistencia;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fiap.Web.CheckPoint02.Controllers
{
    public class EquipeController : Controller
    {

        private CorridaContext _context;


        public EquipeController(CorridaContext context)
        {
            _context = context;
        }


        //-----------------------------------

        public IActionResult Index()
        {
            ViewBag.equipes = _context.Equipes.ToList();
            return View();
        }


        //-----------------------------------------

        [HttpPost]
        public IActionResult Cadastrar(Equipe equipe)
        {
            _context.Equipes.Add(equipe);
            _context.SaveChanges();
            TempData["msg"] = "Equipe Registrada !!!";
            return RedirectToAction("Index");
        }

        //----------------------------------------

    }
}
