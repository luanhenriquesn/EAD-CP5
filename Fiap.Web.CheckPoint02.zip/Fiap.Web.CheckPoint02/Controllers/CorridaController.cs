﻿using Fiap.Web.CheckPoint02.Models;
using Fiap.Web.CheckPoint02.Persistencia;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fiap.Web.CheckPoint02.Controllers
{
    public class CorridaController : Controller
    {
        private CorridaContext _context;


        public CorridaController(CorridaContext context)
        {
            _context = context;
        }


        //-----------------------------------

        public IActionResult Index()
        {
            List<Corrida> corridas = _context.Corridas.ToList();
            return View(corridas);
        }


        //-----------------------------------------

        [HttpGet]
        public IActionResult Cadastrar()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Cadastrar(Corrida corrida)
        {
            _context.Corridas.Add(corrida);
            _context.SaveChanges();
            TempData["msg"] = "Corrida Cadastrada com SUCESSO !!!";
            return RedirectToAction("Index");
        }

        //----------------------------------------
    }
}

