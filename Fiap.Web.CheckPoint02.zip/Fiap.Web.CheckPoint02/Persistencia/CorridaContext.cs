﻿using Fiap.Web.CheckPoint02.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fiap.Web.CheckPoint02.Persistencia
{
    public class CorridaContext : DbContext
    {

        public DbSet<Piloto> Pilotos { get; set; }
        public DbSet<Carro> Carros { get; set; }
        public DbSet<Equipe> Equipes { get; set; }
        public DbSet<Corrida> Corridas { get; set; }
        public DbSet<EquipeCorrida> EquipesCorridas { get; set; }


        public CorridaContext(DbContextOptions op) :base(op) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<EquipeCorrida>().HasKey(c => new { c.EquipeId, c.CorridaId });

            modelBuilder.Entity<EquipeCorrida>()
                .HasOne(c => c.Equipe)
                .WithMany(c => c.EquipesCorridas)
                .HasForeignKey(c => c.EquipeId);

            modelBuilder.Entity<EquipeCorrida>()
                .HasOne(c => c.Corrida)
                .WithMany(c => c.EquipesCorridas)
                .HasForeignKey(c => c.CorridaId);

            base.OnModelCreating(modelBuilder);
        }

    }
}
