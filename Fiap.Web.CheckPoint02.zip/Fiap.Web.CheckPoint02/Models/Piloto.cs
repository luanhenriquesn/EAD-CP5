﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Fiap.Web.CheckPoint02.Models
{
    [Table("Tbl_Piloto")]
    public class Piloto
    {
        [Column("Id"), HiddenInput]
        public int PilotoId { get; set; }

        [Required, MaxLength(80)]
        public string Nome { get; set; }

        [Column("Dt_Nascimento"), Required, Display(Name = "Data de Nascimento"), DataType(DataType.Date)]
        public DateTime DataNascimento { get; set; }

        public double? Peso { get; set; }

        [Required, Display(Name = "País")]
        public Pais Pais { get; set; }


    }
}
