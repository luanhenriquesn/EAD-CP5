﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fiap.Web.CheckPoint02.Models
{
    public enum Pais
    {

        Brasil, Portugal, Canadá, Espanha, Argentina, França, Alemanha

    }
}
