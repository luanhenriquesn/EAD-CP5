﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Fiap.Web.CheckPoint02.Models
{
    [Table("Tbl_Corrida")]
    public class Corrida
    {
        [Column("Id"), HiddenInput]
        public int CorridaId { get; set; }

        [Column("Nome_Circuito"), Display(Name = "Nome do Circuito"), Required, MaxLength(50)]
        public string NomeCircuito { get; set; }

        [Required, Display(Name = "País")]
        public Pais Pais { get; set; }

        [Column("Dt_Corrida"), Required, Display(Name = "Data da Corrida"), DataType(DataType.Date)]
        public DateTime DataCorrida { get; set; }

        public bool PitStop { get; set; }

        //N:M
        public ICollection<EquipeCorrida> EquipesCorridas { get; set; }

    }
}
