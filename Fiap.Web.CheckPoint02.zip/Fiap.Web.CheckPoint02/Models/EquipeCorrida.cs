﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Fiap.Web.CheckPoint02.Models
{
    [Table("Tbl_Equipe_Corrida")]
    public class EquipeCorrida
    {

        public Equipe Equipe { get; set; }
        public int EquipeId { get; set; }
        public Corrida Corrida { get; set; }
        public int CorridaId { get; set; }

    }
}
