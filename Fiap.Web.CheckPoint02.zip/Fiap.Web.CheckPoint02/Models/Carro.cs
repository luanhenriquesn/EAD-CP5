﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Fiap.Web.CheckPoint02.Models
{
    [Table("Tbl_Carro")]
    public class Carro
    {
        [Column("Id"), HiddenInput]
        public int CarroId { get; set; }

        [Required, MaxLength(40)]
        public string Marca { get; set; }

        [Required, MaxLength(40)]
        public string Modelo { get; set; }

        [Column("Dt_Fabricacao"), Required, Display(Name = "Data de Fabricação"), DataType(DataType.Date)]
        public DateTime DataFabricacao { get; set; }

        [Display(Name = "Automático")]
        public bool Automatico { get; set; }

        //1:1
        public Piloto Piloto { get; set; }
        public int PilotoId { get; set; }


        //N:1
        public Equipe Equipe { get; set; }
        public int EquipeId { get; set; }

    }
}
