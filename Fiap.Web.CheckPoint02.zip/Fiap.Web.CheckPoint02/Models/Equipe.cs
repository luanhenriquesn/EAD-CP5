﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Fiap.Web.CheckPoint02.Models
{
    [Table("Tbl_Equipe")]
    public class Equipe
    {
        [Column("Id"), HiddenInput]
        public int EquipeId { get; set; }

        [Required, MaxLength(50)]
        public string Nome { get; set; }

        [Required, Display(Name = "País")]
        public Pais Pais { get; set; }

        [Column("Nome_Tecnico"), Display(Name = "Nome do Técnico"), Required, MaxLength(80)]
        public string NomeTecnico{ get; set; }

        //1:N
        public ICollection<Carro> Carros { get; set; }

        //N:M
        public ICollection<EquipeCorrida> EquipesCorridas { get; set; }

    }
}
