﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Fiap.Web.CheckPoint02.Migrations
{
    public partial class comecobanco : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Tbl_Corrida",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome_Circuito = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Pais = table.Column<int>(type: "int", nullable: false),
                    Dt_Corrida = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PitStop = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Corrida", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Equipe",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Pais = table.Column<int>(type: "int", nullable: false),
                    Nome_Tecnico = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Equipe", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Piloto",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: false),
                    Dt_Nascimento = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Peso = table.Column<double>(type: "float", nullable: true),
                    Pais = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Piloto", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Equipe_Corrida",
                columns: table => new
                {
                    EquipeId = table.Column<int>(type: "int", nullable: false),
                    CorridaId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Equipe_Corrida", x => new { x.EquipeId, x.CorridaId });
                    table.ForeignKey(
                        name: "FK_Tbl_Equipe_Corrida_Tbl_Corrida_CorridaId",
                        column: x => x.CorridaId,
                        principalTable: "Tbl_Corrida",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Tbl_Equipe_Corrida_Tbl_Equipe_EquipeId",
                        column: x => x.EquipeId,
                        principalTable: "Tbl_Equipe",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Carro",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Marca = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    Modelo = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    Dt_Fabricacao = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Automatico = table.Column<bool>(type: "bit", nullable: false),
                    PilotoId = table.Column<int>(type: "int", nullable: false),
                    EquipeId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Carro", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Tbl_Carro_Tbl_Equipe_EquipeId",
                        column: x => x.EquipeId,
                        principalTable: "Tbl_Equipe",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Tbl_Carro_Tbl_Piloto_PilotoId",
                        column: x => x.PilotoId,
                        principalTable: "Tbl_Piloto",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_Carro_EquipeId",
                table: "Tbl_Carro",
                column: "EquipeId");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_Carro_PilotoId",
                table: "Tbl_Carro",
                column: "PilotoId");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_Equipe_Corrida_CorridaId",
                table: "Tbl_Equipe_Corrida",
                column: "CorridaId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Tbl_Carro");

            migrationBuilder.DropTable(
                name: "Tbl_Equipe_Corrida");

            migrationBuilder.DropTable(
                name: "Tbl_Piloto");

            migrationBuilder.DropTable(
                name: "Tbl_Corrida");

            migrationBuilder.DropTable(
                name: "Tbl_Equipe");
        }
    }
}
